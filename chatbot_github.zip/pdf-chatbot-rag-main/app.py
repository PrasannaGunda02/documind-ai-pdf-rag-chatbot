import os, re, uuid
from pathlib import Path
from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv

load_dotenv()
BASE = Path(__file__).resolve().parent
UPLOADS = BASE / 'uploads'
UPLOADS.mkdir(exist_ok=True)
app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 20 * 1024 * 1024
sessions = {}


def extract_pdf(path):
    from PyPDF2 import PdfReader
    reader = PdfReader(str(path))
    pages = []
    for i, page in enumerate(reader.pages):
        text = page.extract_text() or ''
        pages.append({'page': i + 1, 'text': text.strip()})
    return pages


def chunk_pages(pages, size=900, overlap=150):
    chunks = []
    for p in pages:
        text = re.sub(r'\s+', ' ', p['text']).strip()
        if not text:
            continue
        start = 0
        while start < len(text):
            end = min(len(text), start + size)
            chunks.append({'text': text[start:end], 'page': p['page']})
            if end == len(text):
                break
            start = end - overlap
    return chunks


def lexical_retrieve(chunks, question, k=5):
    terms = set(re.findall(r'[a-zA-Z0-9]{3,}', question.lower()))
    scored = []
    for c in chunks:
        words = set(re.findall(r'[a-zA-Z0-9]{3,}', c['text'].lower()))
        score = len(terms & words) / max(1, len(terms))
        scored.append((score, c))
    return [c for s, c in sorted(scored, key=lambda x: x[0], reverse=True)[:k] if s > 0] or chunks[:k]


def llm_answer(question, contexts):
    key = os.getenv('OPENROUTER_API_KEY')
    if not key:
        return None
    try:
        from openai import OpenAI
        client = OpenAI(base_url='https://openrouter.ai/api/v1', api_key=key)
        context = '\n\n'.join(f"[Page {c['page']}] {c['text']}" for c in contexts)
        response = client.chat.completions.create(
            model=os.getenv('OPENROUTER_MODEL', 'openai/gpt-4o-mini'),
            messages=[
                {'role': 'system', 'content': 'Answer only from the supplied PDF context. If the answer is not present, say you could not find it in the document.'},
                {'role': 'user', 'content': f'Context:\n{context}\n\nQuestion: {question}'},
            ],
        )
        return response.choices[0].message.content
    except Exception:
        return None


def fallback_answer(question, contexts):
    if not contexts:
        return 'I could not find relevant information in the uploaded PDF.'
    qwords = set(re.findall(r'[a-zA-Z0-9]{3,}', question.lower()))
    sentences = []
    for c in contexts:
        for sentence in re.split(r'(?<=[.!?])\s+', c['text']):
            overlap = len(qwords & set(re.findall(r'[a-zA-Z0-9]{3,}', sentence.lower())))
            if overlap >= 1:
                sentences.append((overlap, sentence, c['page']))
    sentences = sorted(sentences, key=lambda x: x[0], reverse=True)[:4]
    if not sentences:
        return contexts[0]['text'][:900] + ('…' if len(contexts[0]['text']) > 900 else '')
    return ' '.join(s for _, s, _ in sentences)


@app.get('/')
def home():
    return render_template('home.html')


@app.get('/workspace')
def workspace():
    return render_template('workspace.html')


@app.get('/about')
def about():
    return render_template('about.html')


@app.post('/api/upload')
def upload():
    f = request.files.get('file')
    if not f or not f.filename.lower().endswith('.pdf'):
        return jsonify(error='Please upload a PDF file.'), 400
    sid = uuid.uuid4().hex
    safe_name = Path(f.filename).name
    path = UPLOADS / f'{sid}.pdf'
    f.save(path)
    try:
        pages = extract_pdf(path)
    except Exception as exc:
        path.unlink(missing_ok=True)
        return jsonify(error=f'Could not read PDF: {exc}'), 400
    chunks = chunk_pages(pages)
    sessions[sid] = {
        'name': safe_name,
        'pages': pages,
        'chunks': chunks,
        'messages': [],
    }
    return jsonify(
        session_id=sid,
        filename=safe_name,
        pages=len(pages),
        chunks=len(chunks),
        characters=sum(len(p['text']) for p in pages),
    )


@app.post('/api/chat')
def chat():
    data = request.get_json() or {}
    sid = data.get('session_id')
    question = (data.get('question') or '').strip()
    if sid not in sessions:
        return jsonify(error='Session expired. Please upload the PDF again.'), 404
    if not question:
        return jsonify(error='Enter a question.'), 400
    session = sessions[sid]
    contexts = lexical_retrieve(session['chunks'], question)
    answer = llm_answer(question, contexts) or fallback_answer(question, contexts)
    sources = [
        {'page': c['page'], 'snippet': c['text'][:180] + ('…' if len(c['text']) > 180 else '')}
        for c in contexts
    ]
    session['messages'].append({'role': 'user', 'text': question})
    session['messages'].append({'role': 'assistant', 'text': answer, 'sources': sources})
    return jsonify(answer=answer, sources=sources, used_llm=bool(os.getenv('OPENROUTER_API_KEY')))


@app.get('/api/history/<sid>')
def history(sid):
    if sid not in sessions:
        return jsonify(error='Not found'), 404
    return jsonify(messages=sessions[sid]['messages'])


@app.get('/api/health')
def health():
    return jsonify(status='ok', llm=bool(os.getenv('OPENROUTER_API_KEY')))


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=int(os.getenv('PORT', 5000)), debug=True)
