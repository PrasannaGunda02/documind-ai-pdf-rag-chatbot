# DocuMind — AI PDF RAG Chatbot

DocuMind is a portfolio-ready web application for asking questions about PDF documents. It includes a polished landing page, document workspace, PDF upload, retrieval, optional OpenRouter LLM answers, page sources, chat history, dark mode, and a Flask REST API.

## Features
- Responsive homepage with hero, features, workflow and CTA
- PDF upload up to 20 MB
- PDF text extraction and chunking
- Retrieval-based document question answering
- Optional OpenRouter LLM integration
- Extractive fallback when no API key is configured
- Page-level source badges
- Session chat history
- Dark mode
- Drag-and-drop upload
- Health endpoint
- GitHub-safe `.env.example` and `.gitignore`

## Run in VS Code — Windows PowerShell

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
python app.py
```

Then open **http://127.0.0.1:5000**.

> Do not use VS Code Live Server (`127.0.0.1:5500`) for this project. Live Server only serves the static files and will show a folder listing. Flask must run `app.py` so that the API endpoints work.

## Optional AI setup

Open `.env` and add:

```env
OPENROUTER_API_KEY=your_key_here
OPENROUTER_MODEL=openai/gpt-4o-mini
```

Without an API key, the application still provides a retrieval/extractive fallback answer.

## Routes
- `/` — landing page
- `/workspace` — PDF upload and chat workspace
- `/about` — project information
- `/api/upload` — upload and index PDF
- `/api/chat` — ask a question
- `/api/history/<session_id>` — session history
- `/api/health` — health check

## Architecture
Browser → Flask → PDF extraction → chunking → retrieval → optional OpenRouter LLM → answer + page sources

## GitHub safety
Never commit `.env`, API keys, private PDFs, `uploads/`, `__pycache__/`, or virtual environments.
