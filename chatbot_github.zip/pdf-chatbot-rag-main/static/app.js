let sid = null;
const $ = id => document.getElementById(id);

function toggleTheme() {
  document.body.classList.toggle('dark');
  localStorage.theme = document.body.classList.contains('dark') ? 'dark' : 'light';
}
if (localStorage.theme === 'dark') document.body.classList.add('dark');

function suggest(q) {
  if ($('question')) $('question').value = q;
  if (sid) sendQuestion();
  else if ($('file')) $('file').click();
}

function resetApp() {
  sid = null;
  if ($('file')) $('file').value = '';
  if ($('welcome')) $('welcome').classList.remove('hidden');
  if ($('chat')) $('chat').classList.add('hidden');
  if ($('messages')) $('messages').innerHTML = '';
  if ($('docCard')) $('docCard').innerHTML = '<div class="doc-empty">No PDF uploaded yet</div>';
}

async function uploadPDF(file) {
  if (!file) return;
  if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
    alert('Please select a PDF file.'); return;
  }
  if (file.size > 20 * 1024 * 1024) { alert('PDF must be 20 MB or smaller.'); return; }
  const fd = new FormData(); fd.append('file', file);
  if ($('docCard')) $('docCard').innerHTML = '<div class="doc-loading">Uploading and indexing…</div>';
  try {
    const r = await fetch('/api/upload', {method:'POST', body:fd});
    const d = await r.json();
    if (!r.ok) throw Error(d.error || 'Upload failed');
    sid = d.session_id;
    if ($('docCard')) $('docCard').innerHTML = `<div class="doc-file">PDF</div><div class="doc-info"><b>${escapeHtml(d.filename)}</b><span>${d.pages} pages · ${d.chunks} chunks</span></div>`;
    if ($('chatDocName')) $('chatDocName').textContent = d.filename;
    if ($('chatDocMeta')) $('chatDocMeta').textContent = `${d.pages} pages · ${d.chunks} searchable chunks`;
    $('welcome').classList.add('hidden'); $('chat').classList.remove('hidden');
    addMsg('assistant', `Your document is ready. I indexed ${d.pages} pages into ${d.chunks} searchable chunks. Ask me anything about it.`);
  } catch (e) { alert(e.message); resetApp(); }
}

if ($('file')) $('file').addEventListener('change', e => uploadPDF(e.target.files[0]));
const dz = $('dropzone');
if (dz) {
  ['dragenter','dragover'].forEach(ev => dz.addEventListener(ev, e => {e.preventDefault(); dz.classList.add('dragging');}));
  ['dragleave','drop'].forEach(ev => dz.addEventListener(ev, e => {e.preventDefault(); dz.classList.remove('dragging');}));
  dz.addEventListener('drop', e => uploadPDF(e.dataTransfer.files[0]));
}

function addMsg(role, text, sources=[]) {
  const el = document.createElement('div'); el.className = 'msg ' + role;
  const bubble = document.createElement('div'); bubble.className = 'bubble'; bubble.textContent = text;
  el.appendChild(bubble);
  if (sources.length) {
    const wrap = document.createElement('div'); wrap.className='sources';
    sources.forEach(x => { const s=document.createElement('span'); s.className='source'; s.textContent=`Page ${x.page}`; s.title=x.snippet || ''; wrap.appendChild(s); });
    el.appendChild(wrap);
  }
  $('messages').appendChild(el); $('messages').scrollTop = $('messages').scrollHeight;
  return el;
}

async function sendQuestion() {
  if (!sid) return;
  const q = $('question').value.trim(); if (!q) return;
  addMsg('user', q); $('question').value=''; $('question').focus();
  const pending = addMsg('assistant', 'Searching the document…');
  $('sendBtn').disabled = true;
  try {
    const r = await fetch('/api/chat', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({session_id:sid, question:q})});
    const d = await r.json(); if (!r.ok) throw Error(d.error || 'Request failed');
    pending.querySelector('.bubble').textContent = d.answer;
    if (d.sources?.length) {
      const wrap=document.createElement('div'); wrap.className='sources';
      d.sources.forEach(x=>{const s=document.createElement('span');s.className='source';s.textContent=`Page ${x.page}`;s.title=x.snippet||'';wrap.appendChild(s);});
      pending.appendChild(wrap);
    }
  } catch(e) { pending.querySelector('.bubble').textContent='Error: '+e.message; }
  $('sendBtn').disabled = false;
}

if ($('question')) $('question').addEventListener('keydown', e => { if (e.key==='Enter' && !e.shiftKey) { e.preventDefault(); sendQuestion(); }});
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}
